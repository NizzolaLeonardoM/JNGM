--Discordo
function c28.initial_effect(c)
	aux.AddRitualProcEqual2Code2(c,27)
end
