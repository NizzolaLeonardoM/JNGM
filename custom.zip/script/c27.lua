--Celty
function c27.initial_effect(c)
	c:EnableReviveLimit()
end
